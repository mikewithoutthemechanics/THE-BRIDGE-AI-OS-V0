# Design System: Atmospheric Precision

## 1. Overview & Creative North Star
**Creative North Star: "The Obsidian Monolith"**

This design system is not a collection of components; it is a digital environment defined by volumetric depth and tactile precision. We are moving away from the "flat web" toward a "physical digitalism" inspired by high-end industrial design. 

To break the "template" look, this system utilizes **intentional asymmetry** and **atmospheric layering**. Elements do not simply sit on a grid; they float within a deep, three-dimensional space. We leverage overlapping containers, oversized typography scales, and "optical weight" to create a premium, editorial experience that feels as much like a high-end film sequence as it does a functional interface.

---

## 2. Colors & Atmospheric Depth

The palette is anchored in **Midnight Obsidian** (`#131315`), designed to absorb light, while vibrant "M2-inspired" accents provide the "soul" of the interface.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of obsidian and frosted glass.
- **Base Layer:** Use `surface` (`#131315`) for the global background.
- **Primary Containers:** Use `surface_container` (`#1f1f21`) with a `xl` (48px) radius.
- **Nested Content:** To define internal hierarchy, move to `surface_container_high` (`#2a2a2c`).
- **Floating Elements:** Use `surface_bright` (`#39393b`) to suggest proximity to the light source.

### The "No-Line" Rule
**Explicit Instruction:** 1px solid borders for sectioning are strictly prohibited. 
Boundaries must be defined solely through background color shifts or tonal transitions. For example, a `surface_container_low` section sitting against a `surface` background provides all the definition needed. If a separator is required, use a 48px–64px vertical margin rather than a line.

### Signature Textures & Glassmorphism
To achieve the "M2" feel, use **Glassmorphism** for navigation bars and floating modals:
- **Background:** `surface` at 60% opacity.
- **Backdrop Blur:** 40px – 64px.
- **Satin Gradient:** Main CTAs should use a linear gradient from `primary` (`#aac7ff`) to `primary_container` (`#0066cc`) at a 135-degree angle to mimic light hitting a metallic surface.

---

## 3. Typography

The typography scale utilizes **Inter** (as a high-quality SF Pro equivalent) to convey an editorial, authoritative tone.

*   **Display (Lg/Md):** These are your "Hero" moments. Use `display-lg` (3.5rem) with tight leading and `-0.02em` tracking for a dense, high-end feel.
*   **Headlines:** Use `headline-lg` (2rem) to introduce sections. Maintain a "weight contrast": pair a Semibold headline with a Regular body to create sophisticated hierarchy.
*   **Body:** `body-lg` (1rem) is the workhorse. Ensure a line height of `1.6` to provide the "breathing room" essential to premium design.
*   **Letter Spacing:** For `label-sm` and uppercase sub-headers, increase tracking to `0.1em` to evoke luxury brand aesthetics.

---

## 4. Elevation & Depth

We convey importance through **Tonal Layering** rather than traditional structural lines.

### The Layering Principle
Depth is achieved by stacking the surface tiers.
- Place a `surface_container_lowest` card on a `surface_container_low` section to create a "recessed" look.
- Place a `surface_container_highest` card on a `surface` background to create a "lifted" look.

### Ambient Shadows
When an element must float (e.g., a dropdown or modal), use an **Ambient Shadow**:
- **Y-Offset:** 20px | **Blur:** 60px.
- **Color:** `on_surface` at 6% opacity. This mimics natural light occlusion rather than a "drop shadow" effect.

### The "Ghost Border" Fallback
If a container lacks contrast against a background, use a **Ghost Border**:
- **Stroke:** 1px.
- **Color:** `outline_variant` (`#414753`) at **15% opacity**. This creates a "light-catching edge" rather than a hard boundary.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `xl` rounded corners, and a subtle `inner-shadow` (white at 10%) on the top edge to create a 3D "pressed" metal look.
- **Secondary:** `surface_container_highest` background. No border.
- **States:** On hover, the element should scale by 1.02x with a `cubic-bezier(0.2, 0.8, 0.2, 1)` transition to feel "weighted."

### Cards
- **Construction:** Use `surface_container` with a `xl` (3rem/48px) corner radius.
- **Content:** Forbid the use of divider lines. Separate content using the spacing scale (e.g., 24px vertical gap).
- **Interactive:** On hover, shift the background to `surface_container_high`.

### Input Fields
- **Base:** `surface_container_lowest` background. 
- **Focus:** Transition the "Ghost Border" from 15% opacity to 60% opacity of the `primary` color. Do not use high-contrast focus rings.

### Navigation (The Glass Bar)
A fixed top bar using `surface` at 70% opacity with a `64px` backdrop blur. Use `label-md` with `0.05em` tracking for nav items.

---

## 6. Do's and Don'ts

### Do:
- **Do** use generous white space. If you think there's enough space, add 16px more.
- **Do** use parallax effects. Foreground elements should move slightly faster than the "Obsidian" background to reinforce volumetric depth.
- **Do** align items to an asymmetrical grid (e.g., a 60/40 split) to avoid the "bootstrap" look.

### Don't:
- **Don't** use 100% opaque borders or pure black (`#000000`). Use the `surface` tokens to maintain the "atmospheric" feel.
- **Don't** use standard easing. Every transition must feel like it has "momentum"—slow to start, fast in the middle, and a long, smooth deceleration.
- **Don't** use sharp corners. Every container that holds content must have at least a `md` (24px) radius to mimic hardware forms.

---

## 7. Signature Interaction: The "M2" Glow
When a user hovers over a primary card, implement a subtle "Spotlight" effect: a radial gradient (white at 5% opacity) that follows the cursor's position behind the glass surface, mimicking a light source reflecting off a satin-finish metal plate.