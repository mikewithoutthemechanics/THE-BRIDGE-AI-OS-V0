// ============================================================
// Bridge AI OS — PM2 Ecosystem Config
// Usage: pm2 start infra/pm2.config.cjs
//        pm2 reload infra/pm2.config.cjs --update-env
// ============================================================
module.exports = {
  apps: [

    // --------------------------------------------------------
    // 1. SPINE API — Core orchestrator — Node ESM — :4000
    // --------------------------------------------------------
    {
      name: 'spine',
      script: 'v1/spine/index.js',
      cwd: '/opt/bridge-ai-os',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'production',
        PORT: 4000,
      },
      error_file: '/var/log/bridge/spine-error.log',
      out_file:   '/var/log/bridge/spine-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },

    // --------------------------------------------------------
    // 2. LLM GATEWAY — AI router / OpenRouter — Node CJS — :8080
    // --------------------------------------------------------
    {
      name: 'gateway',
      script: 'llm-gateway/server.js',
      cwd: '/opt/bridge-ai-os',
      interpreter: 'node',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '256M',
      env: {
        NODE_ENV: 'production',
        PORT: 8080,
      },
      error_file: '/var/log/bridge/gateway-error.log',
      out_file:   '/var/log/bridge/gateway-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },

    // --------------------------------------------------------
    // 3. DASHBOARD — Revenue / payments / SSE — Node ESM — :4201
    // --------------------------------------------------------
    {
      name: 'dashboard',
      script: 'v1/dashboard/server.js',
      cwd: '/opt/bridge-ai-os',
      interpreter: 'node',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '256M',
      env: {
        NODE_ENV: 'production',
        DASHBOARD_PORT: 4201,
        BRIDGE_DASHBOARD_PORT: 4201,
      },
      error_file: '/var/log/bridge/dashboard-error.log',
      out_file:   '/var/log/bridge/dashboard-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },

    // --------------------------------------------------------
    // 4. AOE MCP — Task router / MCP protocol — Node CJS — :3005
    // --------------------------------------------------------
    {
      name: 'mcp',
      script: 'aoe-mcp/server.js',
      cwd: '/opt/bridge-ai-os',
      interpreter: 'node',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '256M',
      env: {
        NODE_ENV: 'production',
        PORT: 3005,
      },
      error_file: '/var/log/bridge/mcp-error.log',
      out_file:   '/var/log/bridge/mcp-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },

    // --------------------------------------------------------
    // 5. BACKEND — FastAPI / treasury — Python 3.11 — :8000
    // --------------------------------------------------------
    {
      name: 'backend',
      script: '/opt/bridge-ai-os/backend/.venv/bin/uvicorn',
      args: 'main:app --host 0.0.0.0 --port 8000 --workers 2',
      cwd: '/opt/bridge-ai-os/backend',
      interpreter: 'none',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        PYTHONPATH: '/opt/bridge-ai-os/backend',
      },
      error_file: '/var/log/bridge/backend-error.log',
      out_file:   '/var/log/bridge/backend-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },

  ],

  // --------------------------------------------------------
  // Deploy config (used by: pm2 deploy infra/pm2.config.cjs production)
  // --------------------------------------------------------
  deploy: {
    production: {
      user: 'root',
      host: '102.208.228.44',
      ref: 'origin/main',
      repo: 'git@github.com:bridgeaios/BridgeAIOSv2.git',
      path: '/opt/bridge-ai-os',
      'post-deploy':
        'npm install && ' +
        'cd backend && /opt/bridge-ai-os/backend/.venv/bin/pip install -r requirements.txt -q && cd .. && ' +
        'pm2 reload infra/pm2.config.cjs --update-env && ' +
        'pm2 save',
    },
  },
};
