#!/bin/bash
# ============================================================
# Bridge AI OS — Smoke Test
# Tests all services are alive on their expected ports
# Usage: bash scripts/smoke-test.sh
#        bash scripts/smoke-test.sh --remote   (test public URLs)
# ============================================================
set -euo pipefail

REMOTE=false
[[ "${1:-}" == "--remote" ]] && REMOTE=true

PASS=0; FAIL=0
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'

ok()   { echo -e "${GREEN}  ✓ $1${NC}";    ((PASS++)); }
fail() { echo -e "${RED}  ✗ $1${NC}";     ((FAIL++)); }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }

check_port() {
  local name=$1 port=$2 path=${3:-/}
  local url="http://127.0.0.1:${port}${path}"
  local status
  status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null || echo "000")
  if [[ "$status" != "000" && "$status" != "502" && "$status" != "504" ]]; then
    ok "${name} :${port} → HTTP ${status}"
  else
    fail "${name} :${port} → NO RESPONSE (got ${status})"
  fi
}

check_url() {
  local name=$1 url=$2
  local status
  status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 8 "$url" 2>/dev/null || echo "000")
  if [[ "$status" != "000" && "$status" != "502" && "$status" != "504" ]]; then
    ok "${name} → HTTP ${status}"
  else
    fail "${name} → NO RESPONSE (${url})"
  fi
}

echo ""
echo "======================================================"
echo " BRIDGE AI OS — SMOKE TEST"
echo "======================================================"
echo ""

# --------------------------------------------------------
# LOCAL SERVICE CHECKS
# --------------------------------------------------------
echo "[ LOCAL SERVICES ]"
check_port "Spine API"    4000 "/"
check_port "LLM Gateway"  8080 "/"
check_port "Dashboard"    4201 "/"
check_port "AOE MCP"      3005 "/"
check_port "Backend"      8000 "/docs"

echo ""

# --------------------------------------------------------
# PM2 PROCESS CHECKS
# --------------------------------------------------------
echo "[ PM2 PROCESSES ]"
if command -v pm2 &>/dev/null; then
  for svc in spine gateway dashboard mcp backend; do
    status=$(pm2 jlist 2>/dev/null | python3 -c "
import sys, json
procs = json.load(sys.stdin)
for p in procs:
  if p['name'] == '${svc}':
    print(p['pm2_env']['status'])
    sys.exit(0)
print('not found')
" 2>/dev/null || echo "unknown")
    if [[ "$status" == "online" ]]; then
      ok "${svc} → ${status}"
    else
      fail "${svc} → ${status}"
    fi
  done
else
  warn "PM2 not found — skipping process checks"
fi

echo ""

# --------------------------------------------------------
# DATA FILE CHECKS
# --------------------------------------------------------
echo "[ DATA FILES ]"
APP="/opt/bridge-ai-os"
check_file() {
  [ -f "${APP}/$1" ] && ok "$1 exists" || warn "$1 missing (will be created on first run)"
}
check_file "v1/data/bridge_ai_os.db"
check_file "llm-gateway/data/ledger.json"
check_file "llm-gateway/data/keys.json"
check_file "bridge_ai_os/data/event-log.json"
check_file "data/payments.json"
check_file ".env"

echo ""

# --------------------------------------------------------
# REMOTE / PUBLIC URL CHECKS
# --------------------------------------------------------
if $REMOTE; then
  echo "[ PUBLIC URLS ]"
  check_url "api.supaco.ai"                  "https://api.supaco.ai/"
  check_url "gateway.bridge-ai-os.co.za"    "https://gateway.bridge-ai-os.co.za/"
  check_url "bridge-ai-os.com"              "https://bridge-ai-os.com/"
  check_url "supaco.ai"                     "https://supaco.ai/"
  echo ""
fi

# --------------------------------------------------------
# SUMMARY
# --------------------------------------------------------
echo "======================================================"
TOTAL=$((PASS + FAIL))
if [[ $FAIL -eq 0 ]]; then
  echo -e "${GREEN} ✓ ALL ${TOTAL} CHECKS PASSED${NC}"
else
  echo -e "${RED} ✗ ${FAIL}/${TOTAL} CHECKS FAILED${NC}"
fi
echo "======================================================"
echo ""

exit $FAIL
