#!/usr/bin/env node
// ============================================================
// Bridge AI OS — Web Terminal Server
// Runs ON the VPS — gives real shell access via WebSocket
//
// Install:  npm install node-pty ws
// Run:      node deploy/terminal-server.js
// PM2:      pm2 start deploy/terminal-server.js --name terminal
//
// Client connects to: ws://102.208.228.44:7681
// ============================================================

const os   = require('os');
const pty  = require('node-pty');
const WebSocket = require('ws');

const PORT     = process.env.TERMINAL_PORT || 7681;
const APP_DIR  = process.env.APP_DIR || '/opt/bridge-ai-os';
const MAX_CONN = 5; // max simultaneous sessions
const TOKEN    = process.env.TERMINAL_TOKEN || 'bridge-terminal-2025'; // set in .env

let activeConns = 0;

const wss = new WebSocket.Server({ port: PORT });

console.log(`[terminal-server] Listening on ws://0.0.0.0:${PORT}`);
console.log(`[terminal-server] App dir: ${APP_DIR}`);
console.log(`[terminal-server] Token auth: ${TOKEN ? 'enabled' : 'DISABLED (set TERMINAL_TOKEN)'}`);

wss.on('connection', (ws, req) => {
  // Simple token auth via URL query: ws://host:7681/?token=xxx
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');

  if (TOKEN && token !== TOKEN) {
    ws.send('\r\n\x1b[31m[AUTH FAILED] Invalid token. Connection closed.\x1b[0m\r\n');
    ws.close();
    return;
  }

  if (activeConns >= MAX_CONN) {
    ws.send('\r\n\x1b[33m[SERVER] Max connections reached. Try again later.\x1b[0m\r\n');
    ws.close();
    return;
  }

  activeConns++;
  const ip = req.socket.remoteAddress;
  console.log(`[terminal-server] Connection from ${ip} (active: ${activeConns})`);

  // Spawn bash shell in app directory
  const shell = pty.spawn('bash', [], {
    name: 'xterm-256color',
    cols: 220,
    rows: 50,
    cwd: APP_DIR,
    env: {
      ...process.env,
      TERM: 'xterm-256color',
      COLORTERM: 'truecolor',
      HOME: process.env.HOME || '/root',
      USER: process.env.USER || 'root',
      SHELL: '/bin/bash',
    },
  });

  // Welcome banner
  setTimeout(() => {
    shell.write(`echo -e "\\033[38;5;220m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\033[0m"\n`);
    shell.write(`echo -e "\\033[38;5;220m  BRIDGE AI OS — TERMINAL  \\033[38;5;245m$(date)\\033[0m"\n`);
    shell.write(`echo -e "\\033[38;5;220m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\\033[0m"\n`);
    shell.write(`echo -e "\\033[38;5;51m  pm2 status\\033[0m  ·  \\033[38;5;51mbash scripts/smoke-test.sh\\033[0m"\n`);
    shell.write(`echo ""\n`);
  }, 200);

  // Pipe PTY → WebSocket
  shell.onData(data => {
    try { ws.send(data); } catch (_) {}
  });

  // Pipe WebSocket → PTY
  ws.on('message', msg => {
    try {
      const data = JSON.parse(msg);
      if (data.type === 'resize') {
        shell.resize(data.cols, data.rows);
      } else if (data.type === 'input') {
        shell.write(data.data);
      }
    } catch (_) {
      // Raw input (legacy clients)
      shell.write(msg.toString());
    }
  });

  ws.on('close', () => {
    activeConns--;
    console.log(`[terminal-server] Disconnected ${ip} (active: ${activeConns})`);
    try { shell.kill(); } catch (_) {}
  });

  ws.on('error', err => {
    console.error(`[terminal-server] WS error: ${err.message}`);
    try { shell.kill(); } catch (_) {}
  });

  shell.onExit(() => {
    try { ws.close(); } catch (_) {}
  });
});

// Graceful shutdown
process.on('SIGTERM', () => { wss.close(); process.exit(0); });
process.on('SIGINT',  () => { wss.close(); process.exit(0); });
