#!/bin/bash
# ============================================================
# Bridge AI OS — VPS Bootstrap (Ubuntu 22.04 / 24.04)
# Usage: bash setup-vps.sh
# Run as root or sudo user on: root@102.208.228.44
# ============================================================
set -euo pipefail
REPO="https://github.com/bridgeaios/BridgeAIOSv2.git"
APP_DIR="/opt/bridge-ai-os"
NODE_VERSION="20"
PYTHON_VERSION="3.11"

echo "======================================================"
echo " BRIDGE AI OS — VPS SETUP"
echo "======================================================"

# --- 1. System update ---
echo "[1/9] Updating system packages..."
apt-get update -qq && apt-get upgrade -y -qq

# --- 2. Core dependencies ---
echo "[2/9] Installing core dependencies..."
apt-get install -y -qq \
  git curl wget unzip build-essential \
  software-properties-common ca-certificates \
  gnupg lsb-release ufw fail2ban

# --- 3. Node.js 20 via NodeSource ---
echo "[3/9] Installing Node.js ${NODE_VERSION}..."
curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
apt-get install -y nodejs
node -v && npm -v

# --- 4. Python 3.11 ---
echo "[4/9] Installing Python ${PYTHON_VERSION}..."
add-apt-repository -y ppa:deadsnakes/ppa
apt-get update -qq
apt-get install -y python${PYTHON_VERSION} python${PYTHON_VERSION}-venv python3-pip
python${PYTHON_VERSION} --version

# --- 5. PM2 process manager ---
echo "[5/9] Installing PM2..."
npm install -g pm2
pm2 startup systemd -u root --hp /root | tail -1 | bash || true

# --- 6. Nginx ---
echo "[6/9] Installing Nginx..."
apt-get install -y nginx
systemctl enable nginx

# --- 7. Cloudflare Tunnel (cloudflared) ---
echo "[7/9] Installing Cloudflare Tunnel..."
curl -L --output /tmp/cloudflared.deb \
  "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb"
dpkg -i /tmp/cloudflared.deb
cloudflared --version

# --- 8. Clone / update repo ---
echo "[8/9] Setting up application..."
if [ -d "$APP_DIR/.git" ]; then
  echo "  → Pulling latest from main..."
  cd "$APP_DIR" && git pull origin main
else
  echo "  → Cloning BridgeAIOSv2..."
  git clone "$REPO" "$APP_DIR"
  cd "$APP_DIR"
fi

# Install Node deps (root + v1 + llm-gateway + aoe-mcp)
echo "  → Installing Node dependencies..."
npm install --prefer-offline 2>/dev/null || npm install
[ -d "v1" ]          && (cd v1 && npm install 2>/dev/null || true)
[ -d "llm-gateway" ] && (cd llm-gateway && npm install 2>/dev/null || true)
[ -d "aoe-mcp" ]     && (cd aoe-mcp && npm install 2>/dev/null || true)

# Python venv + deps for backend
echo "  → Installing Python dependencies..."
if [ -d "backend" ]; then
  python${PYTHON_VERSION} -m venv "$APP_DIR/backend/.venv"
  "$APP_DIR/backend/.venv/bin/pip" install --upgrade pip -q
  "$APP_DIR/backend/.venv/bin/pip" install -r backend/requirements.txt -q
fi

# Copy env template if .env missing
[ ! -f "$APP_DIR/.env" ] && cp "$APP_DIR/.env.example" "$APP_DIR/.env" && \
  echo "  ⚠  .env created from .env.example — FILL IN SECRETS before starting services"

# --- 9. Deploy nginx + PM2 ---
echo "[9/9] Deploying configs..."

# Nginx
cp "$APP_DIR/nginx/bridge-ai-os.conf" /etc/nginx/sites-available/bridge-ai-os 2>/dev/null || true
ln -sf /etc/nginx/sites-available/bridge-ai-os /etc/nginx/sites-enabled/ 2>/dev/null || true
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# PM2
cd "$APP_DIR"
pm2 start infra/pm2.config.cjs
pm2 save

# --- Firewall ---
echo "[UFW] Configuring firewall..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo ""
echo "======================================================"
echo " ✓ BRIDGE AI OS SETUP COMPLETE"
echo " App dir  : $APP_DIR"
echo " PM2      : pm2 status"
echo " Nginx    : systemctl status nginx"
echo " Logs     : pm2 logs"
echo ""
echo " ⚠  NEXT STEPS:"
echo "    1. Edit $APP_DIR/.env with real secrets"
echo "    2. cloudflared tunnel login  (CF Tunnel auth)"
echo "    3. pm2 restart all  (after .env is set)"
echo "    4. bash $APP_DIR/scripts/smoke-test.sh"
echo "======================================================"
