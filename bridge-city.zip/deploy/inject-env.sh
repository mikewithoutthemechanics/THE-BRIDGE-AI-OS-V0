#!/bin/bash
# ============================================================
# Bridge AI OS — Inject .env to VPS + Generate missing secrets
# Usage: bash inject-env.sh
# Run from your LOCAL machine (not the VPS)
# Requires: ssh access to root@102.208.228.44
# ============================================================
set -euo pipefail

VPS="root@102.208.228.44"
APP_DIR="/opt/bridge-ai-os"
ENV_FILE="$(dirname "$0")/.env.production"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo "======================================================"
echo " BRIDGE AI OS — ENV INJECTION"
echo "======================================================"

# Check SSH access
echo -n "Checking SSH access... "
if ! ssh -o ConnectTimeout=5 -q "$VPS" exit 2>/dev/null; then
  echo -e "${RED}FAILED${NC}"
  echo "Cannot reach $VPS — set up SSH key first:"
  echo "  ssh-keygen -t ed25519 -C 'deploy' -f ~/.ssh/bridge_deploy"
  echo "  ssh-copy-id -i ~/.ssh/bridge_deploy.pub $VPS"
  exit 1
fi
echo -e "${GREEN}OK${NC}"

# Auto-generate missing secrets on the VPS
echo "Generating missing secrets on VPS..."
ssh "$VPS" bash << 'REMOTE'
  gen() { openssl rand -hex 32; }
  ENV="/opt/bridge-ai-os/.env"
  
  # Only set if placeholder or missing
  set_if_empty() {
    local key=$1 val=$2
    if grep -q "^${key}=FILL_" "$ENV" 2>/dev/null || ! grep -q "^${key}=" "$ENV" 2>/dev/null; then
      # Remove old placeholder line
      sed -i "/^${key}=/d" "$ENV"
      echo "${key}=${val}" >> "$ENV"
      echo "  → Generated: $key"
    else
      echo "  ✓ Already set: $key"
    fi
  }
  
  [ -f "$ENV" ] || touch "$ENV"
  
  set_if_empty "NEXTAUTH_SECRET"        "$(gen)"
  set_if_empty "SPINE_SERVICE_TOKEN"    "$(gen)"
  set_if_empty "JWT_SECRET"             "$(gen)"
  set_if_empty "SESSION_SECRET"         "$(gen)"
  set_if_empty "BRIDGE_BOOTSTRAP_TOKEN" "$(gen)"
REMOTE

# Push the .env.production as base .env (only if not already present)
echo ""
echo "Pushing .env.production to VPS..."
if ssh "$VPS" "[ -f ${APP_DIR}/.env ]"; then
  echo -e "${YELLOW}  ⚠  .env already exists on VPS — merging new keys only${NC}"
  
  # Only add lines from our file that aren't already set on VPS
  while IFS= read -r line; do
    # Skip comments and blank lines
    [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
    # Skip FILL_ placeholders
    [[ "$line" =~ FILL_ ]] && continue
    
    KEY="${line%%=*}"
    # Only inject if key not already present on VPS
    ssh "$VPS" "grep -q '^${KEY}=' ${APP_DIR}/.env || echo '${line}' >> ${APP_DIR}/.env"
  done < "$ENV_FILE"
  echo -e "${GREEN}  ✓ Merged${NC}"
else
  # Fresh install — push whole file, skip FILL_ lines
  grep -v "FILL_" "$ENV_FILE" | ssh "$VPS" "cat > ${APP_DIR}/.env"
  echo -e "${GREEN}  ✓ Written${NC}"
fi

# Show what still needs manual filling
echo ""
echo "======================================================"
echo -e "${YELLOW} KEYS STILL NEEDING MANUAL VALUES:${NC}"
ssh "$VPS" "grep 'FILL_' ${APP_DIR}/.env 2>/dev/null | cut -d= -f1 | sed 's/^/  → /'" || \
  echo "  (none — all keys populated)"

echo ""
echo "======================================================"
echo " NEXT STEPS:"
echo "  1. SSH in and fill remaining keys:"
echo "     ssh $VPS 'nano ${APP_DIR}/.env'"
echo ""
echo "  2. Restart all services:"
echo "     ssh $VPS 'pm2 restart all'"
echo ""
echo "  3. Smoke test:"
echo "     ssh $VPS 'bash ${APP_DIR}/scripts/smoke-test.sh'"
echo ""
echo -e "${YELLOW}  ⚠  ROTATE your OPENROUTER_API_KEY at https://openrouter.ai/keys${NC}"
echo "     It was committed in plaintext to .env.txt in your repo."
echo "======================================================"
